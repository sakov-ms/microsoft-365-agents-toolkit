# yaml-language-server: $schema=https://aka.ms/m365-agents-toolkits/v1.11/yaml.schema.json
# Visit https://aka.ms/teamsfx-v5.0-guide for details on this file
# Visit https://aka.ms/teamsfx-actions for details on actions
version: v1.11

provision:
  # Creates a Teams app
  - uses: teamsApp/create
    with:
      # Teams app name
      name: {{appName}}-${{APP_NAME_SUFFIX}}
    # Write the information of created resources into environment file for
    # the specified environment variable(s).
    writeToEnvironmentFile:
      teamsAppId: TEAMS_APP_ID

  # Create or reuse an existing Microsoft Entra application for bot.
  - uses: aadApp/create
    with:
      # The Microsoft Entra application's display name
      name: {{appName}}-${{RESOURCE_SUFFIX}}-${{APP_NAME_SUFFIX}}-Bot
      generateClientSecret: true
      signInAudience: AzureADMyOrg
    writeToEnvironmentFile:
      # The Microsoft Entra application's client id created for bot.
      clientId: BOT_ID
      # The Microsoft Entra application's client secret created for bot.
      clientSecret: SECRET_BOT_PASSWORD
      # The Microsoft Entra application's object id created for bot.
      objectId: BOT_OBJECT_ID

  # Deploy Azure infrastructure for local development (Bot Service + OAuth Connection)
  # This creates: SSO App Registration + Azure Bot Service + OAuth Connection
  - uses: arm/deploy
    with:
      subscriptionId: ${{AZURE_SUBSCRIPTION_ID}}
      resourceGroupName: ${{AZURE_RESOURCE_GROUP_NAME}}
      templates:
        - path: ./infra/azure-local.bicep
          parameters: ./infra/azure-local.parameters.json
          deploymentName: Deploy-local-bot-infrastructure
      bicepCliVersion: v0.38.33
    # Note: arm/deploy outputs are automatically captured in ARM_OUTPUTS variable
    # We extract them and write to environment file in the next step


  # Generate runtime appsettings to JSON file
  - uses: file/createOrUpdateJsonFile
    with:
{{#PlaceProjectFileInSolutionDir}}
      target: ../appsettings.Development.json
{{/PlaceProjectFileInSolutionDir}}
{{^PlaceProjectFileInSolutionDir}}
      target: ../{{appName}}/appsettings.Development.json
{{/PlaceProjectFileInSolutionDir}}
      content:
        TokenValidation:
          Audiences:
            ClientId: ${{BOT_ID}}
        Connections:
          BotServiceConnection:
            Settings:
              AuthType: "ClientSecret"
              TenantId: ${{TEAMS_APP_TENANT_ID}}
              ClientId: ${{BOT_ID}}
              ClientSecret: ${{SECRET_BOT_PASSWORD}}
              Scopes: [
                "https://api.botframework.com/.default"
              ]
        AgentApplication:
          StartTypingTimer: true
          RemoveRecipientMention: false
          NormalizeMentions: false
          UserAuthorization:
            AutoSignIn: false
            Handlers:
              SSO:
                Settings:
                  AzureBotOAuthConnectionName: ${{AIFOUNDRYCONNECTIONNAME}}
        ConnectionsMap:
          - ServiceUrl: "*"
            Connection: "BotServiceConnection"
        Logging:
          LogLevel:
            Default: "Information"
            Microsoft.AspNetCore: "Warning"
            Microsoft.Agents: "Warning"
            Microsoft.Hosting.Lifetime: "Information"
        AIServices:
          AzureAIFoundryProjectEndpoint: ${{AZURE_AI_FOUNDRY_PROJECT_ENDPOINT}}
          AgentID: ${{AGENT_ID}}

  # Validate using manifest schema
  - uses: teamsApp/validateManifest
    with:
      # Path to manifest template
      manifestPath: ./appPackage/manifest.json

  # Build Teams app package with latest env value
  - uses: teamsApp/zipAppPackage
    with:
      # Path to manifest template
      manifestPath: ./appPackage/manifest.json
      outputZipPath: ./appPackage/build/appPackage.${{TEAMSFX_ENV}}.zip
      outputFolder: ./appPackage/build

  # Validate app package using validation rules
  - uses: teamsApp/validateAppPackage
    with:
      # Relative path to this file. This is the path for built zip file.
      appPackagePath: ./appPackage/build/appPackage.${{TEAMSFX_ENV}}.zip

  # Apply the Teams app manifest to an existing Teams app in
  # Developer Portal.
  # Will use the app id in manifest file to determine which Teams app to update.
  - uses: teamsApp/update
    with:
      # Relative path to this file. This is the path for built zip file.
      appPackagePath: ./appPackage/build/appPackage.${{TEAMSFX_ENV}}.zip

  - uses: teamsApp/extendToM365
    with:
      # Relative path to the build app package.
      appPackagePath: ./appPackage/build/appPackage.${{TEAMSFX_ENV}}.zip
    # Write the information of created resources into environment file for
    # the specified environment variable(s).
    writeToEnvironmentFile:
      titleId: M365_TITLE_ID
      appId: M365_APP_ID
