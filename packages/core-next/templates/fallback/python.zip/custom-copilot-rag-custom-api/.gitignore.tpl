# TeamsFx files
env/.env.*.user
env/.env.local
env/.env.playground
.env
appPackage/build

# python virtual environment
.venv/
__pycache__/

# others
.deployment/
node_modules/

# Dev tool directories
/devTools/