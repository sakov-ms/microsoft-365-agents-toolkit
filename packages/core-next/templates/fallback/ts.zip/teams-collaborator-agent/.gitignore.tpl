# TeamsFx files
env/.env.*.user
env/.env.local
.localConfigs.playground
.localConfigs
.notification.localstore.json
.notification.playgroundstore.json
appPackage/build

# dependencies
node_modules/

# misc
.env
.deployment
.DS_Store

# build
dist/

# Dev tool directories
/devTools/

# Ignore database files
src/storage/conversations.db