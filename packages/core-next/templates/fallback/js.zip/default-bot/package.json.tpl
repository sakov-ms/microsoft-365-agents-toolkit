{
    "name": "{{SafeProjectNameLowerCase}}",
    "version": "1.0.0",
    "msteams": {
      "teamsAppId": null
    },
    "description": "Microsoft 365 Agents Toolkit echo bot sample",
    "author": "Microsoft",
    "license": "MIT",
    "main": "index.js",
    "scripts": {
        "dev:teamsfx": "env-cmd --silent -f .localConfigs npm run dev",
        "dev:teamsfx:playground": "env-cmd --silent -f .localConfigs.playground npm run dev",
        "dev:teamsfx:launch-playground": "env-cmd --silent -f env/.env.playground agentsplayground start",
        "dev": "nodemon --inspect=9239 --signal SIGINT ./index.js",
        "start": "node ./index.js",
        "watch": "nodemon ./index.js",
        "test": "echo \"Error: no test specified\" && exit 1"
    },
    "dependencies": {
        "@azure/identity": "^4.11.1",
        "@microsoft/teams.apps": "^2.0.0",
        "@microsoft/teams.common": "^2.0.0"
    },
    "devDependencies": {
        "env-cmd": "^10.1.0",
        "nodemon": "^3.1.10"
    }
}
