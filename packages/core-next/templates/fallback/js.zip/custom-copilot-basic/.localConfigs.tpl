# A gitignored place holder file for local runtime configurations
CLIENT_ID=
CLIENT_SECRET=
{{#useOpenAI}}
OPENAI_API_KEY=
{{/useOpenAI}}
{{#useAzureOpenAI}}
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_DEPLOYMENT_NAME=
{{/useAzureOpenAI}}